# DualTitle (C++17 & Rust Anti-Cheat-Safe Universal Edition v4.1)

**DualTitle** is a 100% Anti-Cheat-Safe C++17, Rust, and Win32 application suite featuring your custom **DualTitle Gamepad + Tilted Dual-Subtitle Bars Logo** (`assets/logo.svg`, `assets/logo.png`, `assets/dualtitle.ico`).

## Key Capabilities

1. **100% Anti-Cheat Safe / Zero Injection Architecture**:
   - Never injects DLLs into game processes, never hooks DirectX/Vulkan graphics pipelines, and never opens intrusive process handles (`OpenProcess`).
   - Automatically cleans any legacy synthetic `.utoc`/`.ucas`/`.pak` or injected mod files before launch so every game opens natively without triggering anti-cheat or file-integrity checks.
2. **Choose Any Game You Own & Launch Directly**:
   - Double-click **`DualTitle.bat`** (or **`build_cpp.bat`**) to open the **DualTitle Control Panel GUI**.
   - Automatically scans all drives (`C:` through `Z:`) across Steam, EA App / Origin, Epic Games, Ubisoft Connect, GOG, and custom folders so you can pick any game from the dropdown and click **🚀 Launch Selected Game + In-Game Overlay HUD**.
3. **Interactive In-Game Dual-Subtitle Overlay HUD (Clickable Words & Speed Controls)**:
   - Displays **Primary Subtitle (Top Line in Gold `#FFD700`) + Secondary Subtitle (Bottom Line in Ice-White `#E2E8F0`)** over any running game or application.
   - **Clickable Words on Both Lines**: Click any word in the top or bottom subtitle line to immediately see its translation, phonetic pronunciation, part of speech, gender article, and definition right on the HUD.
   - **In-Game Extra Control Buttons**:
     - `◀ Prev` / `Next ▶`: Step backward or forward through dialogue lines.
     - `▶ Auto:ON/OFF`: Toggle automatic subtitle cadence progression.
     - `- Spd` / `⚡ 1.00x` / `+ Spd`: Control subtitle & reading speed live (`0.25x` to `2.00x`).
     - `⏸ Game (ESC)`: Send a safe standard keyboard pause (`ESC`) without process hooks (`ALT+F9`).
     - `🔲 Borderless`: Convert the active game window to Borderless Fullscreen (`ALT+F11`).
     - `💾 Restore Save`: 1-click Save & Profile restoration right from the HUD.
4. **Automatic Save Backup & 1-Click "💾 Restore Save" Button**:
   - Automatically backs up user save files (`Saved/SaveGames`, `Documents/<App>/settings/PROF_SAVE*`, `Saves`, `*.sav`, profile `.ini`s) to `.dualtitle_save_backup/` and `backups/` before every operation.
   - Click **💾 Restore Save** in the GUI, on the In-Game HUD, in the System Tray menu, or via **`RESTORE_SAVE.bat`** to restore saved progress at any time.
